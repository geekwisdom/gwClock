﻿Public Class transp



    Sub make_transparent(theform As Form)
        If theform.TransparencyKey = theform.BackColor Then
            theform.TransparencyKey = Color.Plum
        Else
            theform.TransparencyKey = theform.BackColor
        End If
    End Sub


    Private Sub SetBackgroundColorToolStripMenuItem_Click(theform As Form)
        Dim MyDialog As New ColorDialog()
        MyDialog.AllowFullOpen = False ' Keeps the user from selecting a custom color.
        MyDialog.ShowHelp = True  ' Allows the user to get help. (The default is false.)

        ' Update the text box color if the user clicks OK 
        If (MyDialog.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            ' Button2.Text = MyDialog.Color.ToString
        End If
        theform.BackColor = MyDialog.Color
    End Sub

    Sub TrackBar1_Scroll(theform As Form, tb As TrackBar)
        theform.Opacity = tb.Value / 10 '+ 0.01

    End Sub

    Sub toggle_borders(theform As Form)
        If theform.FormBorderStyle = Windows.Forms.FormBorderStyle.None Then
            theform.FormBorderStyle = Windows.Forms.FormBorderStyle.Sizable
        Else
            theform.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        End If
    End Sub


End Class
