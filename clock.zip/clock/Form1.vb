﻿Public Class Form1
    Dim cls As New transp
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label1.Text = TimeOfDay
    End Sub

    Private Sub Form1_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Label1.Height = Me.Height
        Label1.Width = Me.Width
        Label1.Font = New Font(Label1.Font.FontFamily, Me.Height / 2.5)
        PictureBox1.Height = Me.Height
        PictureBox1.Width = Me.Width
    End Sub

    Private Sub TrackBar1_Scroll(sender As Object, e As EventArgs) Handles TrackBar1.Scroll
        ' cls.TrackBar1_Scroll(Me, sender)
        Me.Opacity = sender.Value / 100 '+ 0.01
        Me.Text = Me.Opacity

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cls.make_transparent(Me)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Parent = PictureBox1
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        cls.toggle_borders(Me)
    End Sub
End Class
